# Profile-Card-UI
Simple profile card UI using HTML &amp; CSS.

UI View 1

![UI View 1](https://github.com/yourcodingcompanion/Profile-Card-UI/blob/master/Screenshots/ss-1.png?raw=true)

UI View 2

![UI View 2](https://github.com/yourcodingcompanion/Profile-Card-UI/blob/master/Screenshots/ss-2.png?raw=true)
